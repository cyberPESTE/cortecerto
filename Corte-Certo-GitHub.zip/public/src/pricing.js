export const round = value => Math.round((Number(value) + Number.EPSILON) * 100) / 100;
export const materialCostPerM2 = (purchasePrice, widthM, lengthM) => {
  if (purchasePrice < 0 || widthM <= 0 || lengthM <= 0) throw new RangeError('Informe preço e dimensões válidos.');
  return purchasePrice / (widthM * lengthM);
};
export const materialCost = ({ purchasePrice, widthM, lengthM, usedWidthM, usedLengthM, wastePercent = 0 }) => {
  if (wastePercent < 0) throw new RangeError('O desperdício não pode ser negativo.');
  const area = usedWidthM * usedLengthM;
  return round(area * (1 + wastePercent / 100) * materialCostPerM2(purchasePrice, widthM, lengthM));
};
export const laborCost = (minutes, hourlyRate) => {
  if (minutes < 0 || hourlyRate < 0) throw new RangeError('Tempo e valor por hora devem ser positivos.');
  return round((minutes / 60) * hourlyRate);
};
export const machineCostPerHour = ({ purchasePrice = 0, usefulLifeHours = 0, annualMaintenance = 0, annualEnergy = 0, annualHours = 0, bladePerJob = 0, otherPerHour = 0 }) => {
  const depreciation = usefulLifeHours > 0 ? purchasePrice / usefulLifeHours : 0;
  const upkeep = annualHours > 0 ? (annualMaintenance + annualEnergy) / annualHours : 0;
  return depreciation + upkeep + otherPerHour + bladePerJob;
};
export const priceBreakdown = ({ material = 0, machine = 0, labor = 0, overhead = 0, other = 0, pricingMode = 'margin', target = 50, customPrice = null }) => {
  if (!Number.isFinite(target) || target < 0 || target > 500) throw new RangeError('Use um percentual entre 0% e 500%.');
  const totalCost = round(material + machine + labor + overhead + other);
  const suggestedPrice = pricingMode === 'markup' ? round(totalCost * target / 100) : round(totalCost * (1 + target / 100));
  const minPrice = totalCost;
  const price = customPrice === null ? suggestedPrice : Number(customPrice);
  const profit = price === null ? null : round(price - totalCost);
  return { totalCost, suggestedPrice, minPrice, price, profit, margin: price > 0 ? round((profit / price) * 100) : 0, markup: totalCost > 0 && price !== null ? round((price / totalCost) * 100) : 0 };
};
