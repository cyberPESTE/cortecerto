import test from 'node:test';
import assert from 'node:assert/strict';
import { materialCostPerM2, materialCost, laborCost, priceBreakdown } from '../src/pricing.js';

test('converts a roll purchase into price per square meter', () => assert.equal(Number(materialCostPerM2(120, .61, 25).toFixed(2)), 7.87));
test('adds the selected waste percentage to consumed area', () => assert.equal(materialCost({ purchasePrice: 120, widthM: .61, lengthM: 25, usedWidthM: .3, usedLengthM: .5, wastePercent: 10 }), 1.3));
test('calculates labor cost in fractional hours', () => assert.equal(laborCost(25, 25), 10.42));
test('calculates the requested profit as a percentage of cost', () => { const p = priceBreakdown({ material: 6.3, machine: 1.8, labor: 10.42, overhead: 3.1, target: 50 }); assert.equal(p.totalCost, 21.62); assert.equal(p.suggestedPrice, 32.43); assert.equal(p.profit, 10.81); assert.equal(p.margin, 33.33); assert.equal(p.markup, 150); });
test('allows profit up to 500 percent of cost', () => { const p = priceBreakdown({ material: 100, target: 500 }); assert.equal(p.suggestedPrice, 600); assert.equal(p.profit, 500); assert.equal(p.margin, 83.33); assert.equal(p.markup, 600); });
test('calculates markup as price divided by cost', () => { const p = priceBreakdown({ material: 100, pricingMode: 'markup', target: 150 }); assert.equal(p.suggestedPrice, 150); assert.equal(p.margin, 33.33); assert.equal(p.markup, 150); });
test('shows custom price profit, margin, markup and minimum price', () => { const p = priceBreakdown({ material: 80, other: 20, target: 50, customPrice: 130 }); assert.deepEqual([p.minPrice,p.price,p.profit,p.margin,p.markup],[100,130,30,23.08,130]); });
test('rejects non-positive material dimensions', () => { assert.throws(() => materialCostPerM2(120, 0, 25), RangeError); });
test('limits the desired percentage to 500 percent', () => { assert.throws(() => priceBreakdown({ material: 100, target: 501 }), RangeError); });
